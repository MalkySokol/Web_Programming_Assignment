
# Full Screen Animated Sticky Header | Sticky Navigation Bar After Scroll with Html CSS and jQuery

 This website is created inspired by [this video](https://www.youtube.com/watch?v=9fsVN891LGA&t=9s) from Online Tutorials channel.

 
